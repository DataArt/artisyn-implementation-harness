# Sign-off

A **sign-off** is a stop-and-wait gate: the developer must explicitly approve
content, personally run a manual operation, or confirm an out-of-band decision,
before the lifecycle proceeds. It blocks progress until an explicit reply; silence,
a later unrelated message, or an automated notification is never a sign-off.

A step that names itself a sign-off gate is a human checkpoint by design: that stop
is unconditional, never skipped, downgraded to an announcement, or weakened by
routine-work authorization — however small the change looks. Whether a given step
requires a sign-off, and which kind, is a decision made at that step, not by this
pattern; changing it is its own explicit edit, called out on its own, never a side
effect of an unrelated change.

Three common shapes:

- **Content sign-off** — the developer reviews drafted or persisted content and
  confirms it. Present the actual content (in full if reasonably short, or a
  faithful summary for a long artifact); a summary that omits what changed is not
  a basis for approval. Present every item the developer needs to meaningfully
  confirm, regardless of how many you already checked yourself — completeness here
  is never weakened by how much self-run evidence already exists; adapting what's
  asked to match what the step actually became is not the same as asking for less.
- **Manual operation** — an action only the developer can run (branch checkout, a
  commit, a guarded command). Propose the exact command and wait for them to run
  it and confirm — never run it yourself, even once they've said yes.
- **External confirmation** — a fact only the developer can attest to (an MR was
  approved, a manual check passed). This can never be inferred, self-certified, or
  substituted by an automated pass, however thorough.

Running an available, non-guarded check yourself (a build, typecheck, curl) as a
debugging aid is routine authorized work and does not require asking first — but it
never substitutes for the sign-off itself. Verification is a developer confirmation
gate, not something self-certified because a command exited 0 in your sandbox: your
sandbox is not the developer's machine, and tool availability, versions, or network
behavior can differ. Report exactly what you ran and its real result, then still
present every verification item the step calls for, and stop and wait; a self-run
check answers whether it passed for you, never whether the developer signs off to
proceed. Having Bash access, or a delegated worker lacking a tool, is never a reason
to take a sign-off gate over yourself. A worker's own satellite-review verdict is an
input to the gate, never a substitute for it — the orchestrator still runs the gate
in full, and a worker never presents to the developer directly.

# Pattern: Design Quality Gate

Run this gate after drafting and before Review Gate. Inspect only the artifacts
listed in `design/Report.md` State.

1. Map every framed requirement and constraint to a decision or an explicit
   not-applicable record.
2. Confirm every material concern in the preliminary scan has an artifact,
   owning requirement, or developer decision, with evidence in `design/Report.md`.
3. Check that solution artifacts contain decisions and interfaces, not rationale,
   rejected options, or unresolved placeholders.
4. Treat `solution/Architecture.md` as the canonical E2E record: every material decision in
   Frame, Evaluate, WAF findings and review feedback has a corresponding decision,
   consequence and verification obligation there; every representative flow is
   traceable end to end. Confirm `solution/Design.md`, `solution/Stack.md` and `solution/Efforts.md` do not add
   conflicting or unrecorded material decisions.
5. Render every Mermaid diagram with the repository's available Mermaid CLI or
   documented equivalent. If no CLI is available, record that limitation and run
   a syntax-oriented inspection.
6. Check all relative links in the selected artifacts resolve from their file
   locations.
7. Record pass/fail and remediation in `design/Report.md` before opening the review gate.

Any failed item keeps Solution incomplete until resolved or explicitly accepted by
the developer.

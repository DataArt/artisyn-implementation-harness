---
skill: where-we-are
output: .claude/skills/where-we-are/SKILL.md
companion_templates:
  - report-template.md
---

## Purpose

Produces a delivery gap report: what has been designed in Target Architecture (HLD) vs documented in System Architecture (LLD) vs implemented in the codebase. Delegates code scanning to `@architect`.

## Substitutions

| Placeholder                | Source                                    | Notes                                                                                                                                                                                                                                                                                                                                    |
| -------------------------- | ----------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `{{LLD_FOLDER_STRUCTURE}}` | Stage 1b — detected from repo             | The `docs/System Architecture (LLD)/` subfolder structure. Detect from existing `docs/System Architecture (LLD)/` folder or use generic container names from Q3. Do not hardcode ncfc-specific folders (Canonical, Compute, Synthetic, Serving, Data, Infrastructure)                                                                    |
| `{{CODE_SCAN_TARGET}}`     | Q2/Q3 — detected monorepo tool and layout | A phrase describing where code lives, matched to the project's actual layout — e.g. "the NX monorepo under `apps/` and `libs/`" for an NX monorepo, "the Turborepo monorepo under `apps/`" for a Turborepo project with no `libs/`, "the codebase" for a single non-monorepo app. Shared with `war`'s `references/02-implementation.md`. |
| `{{BUILD_UNIT_LABEL}}`     | Q2/Q3 — detected monorepo tool            | Same placeholder as `dev`'s INTENT — the generic noun for one buildable unit (`NX project`, `package`, `module`, or the single app's name).                                                                                                                                                                                              |

## Conditionals

None.

## Verify checklist

- [ ] TEMPLATE.md starts with `---` frontmatter containing `name:` (skill name) and `description:` (trigger conditions for this skill)

- [ ] Step 1 reads HLD README to find active version — not hardcoded
- [ ] Step 3 shows the actual LLD folder structure detected from the project (not ncfc's Canonical/Compute/etc.)
- [ ] `{{CODE_SCAN_TARGET}}` and `{{BUILD_UNIT_LABEL}}` in Step 4 are resolved to the project's actual detected monorepo tool and directory layout — never left hardcoded as "NX monorepo" / "`apps/` and `libs/`" for a project that uses a different tool or layout
- [ ] Step 4 `@architect` prompt is bounded: "Return a structured list. Do not write files. Do not make changes."
- [ ] Step 5 gap matrix rows are populated from HLD containers discovered in Step 2, not hardcoded
- [ ] Step 7 uses `report-template.md` from same skill folder
- [ ] Output path: `docs/System Architecture (LLD)/where-we-are/{YYYY-MM-DD}-gap-report.md`

---
skill: design
output: {{provider:skills_root}}/design/SKILL.md
companion_templates:
  - scripts/constants.mjs
  - scripts/utils.mjs
  - scripts/design-metrics.mjs
  - scripts/design-metrics.test.mjs
  - templates/stat.json
  - templates/stat.schema.json
  - patterns/metrics.md
  - templates/frame.md
  - templates/research.md
  - templates/evaluate.md
  - templates/report.md
  - interfaces/contract.md
  - interfaces/architecture.md
  - interfaces/design.md
  - interfaces/stack.md
  - interfaces/efforts.md
  - patterns/approval-sign-off.md
  - patterns/approval-intelligent.md
  - patterns/announce-progress.md
  - patterns/phase-sign-off.md
  - patterns/do-report-commit.md
  - patterns/write-confirm.md
  - patterns/session-continuity.md
  - patterns/satellite-review.md
  - patterns/design-architect-review.md
  - patterns/design-oq-triage.md
  - patterns/multi-decision-split.md
  - patterns/context-resolution.md
  - patterns/docs-writer-authoring.md
  - patterns/waf-review.md
  - patterns/design-quality-gate.md
  - patterns/task-tracking.md
  - references/00-router.md
  - references/00-decision-router.md
  - references/01-context-gathering.md
  - references/02-ceremony.md
  - references/03-frame.md
  - references/04-research.md
  - references/05-evaluate.md
  - references/06-solution.md
  - references/07-review-gate.md
  - references/08-address-feedback.md
  - references/09-publish.md
  - references/10-completion.md
---

## Purpose

The full design lifecycle in one skill: Context Gathering → Ceremony → Frame →
Research → Evaluate → Solution → Review Gate → Address Feedback → Publish →
Completion. Routes to each stage reference in order (or directly to one stage,
on request), stopping once per phase for developer confirmation (two stops —
sign-off, then commit — except Review Gate/Address Feedback, which wait on the
real external MR approval state). Replaces the former separate `design-frame`,
`design-research`, `design-evaluate`, `design-solution`, `design-review-gate`,
`design-review`, `design-address-feedback`, `design-publish` skills — those
stages now live under this one skill's `references/`.

**Context Gathering and Ceremony are separate stages**, mirroring `dev`'s own
split: Context Gathering resolves the ticket/local ID, fetches tracker
context, and identifies the design track/subfolder — read-only, and it
creates the story folder and `design/Report.md`. Ceremony is the only stage
that mutates the tracker or checks out a branch. Frame then writes the
framing content (`design/00 Frame.md`) using what Context Gathering resolved.
This replaces the earlier (4.x/5.x) design where Frame did all three jobs
itself.

Completion owns archiving, tracker sync, and the final commit/PR, separated
out of what Publish used to do alone, and it is also where a design
**declined** at Address Feedback ends up — Publish is skipped for a decline,
since there are no permanent docs to update.

Design-lifecycle artifacts live under `{{DESIGN_STORIES_ROOT}}` —
`docs/Stories/design/` for a Project design, `docs/Stories/product-design/`
for a Product design, identified by Context Gathering as part of track
resolution and never re-derived. Active at `{{DESIGN_STORIES_ROOT}}[{TICKET}] {name}/`,
archived at `{{DESIGN_STORIES_ROOT}}approved/[{TICKET}] {name}/` or
`{{DESIGN_STORIES_ROOT}}declined/[{TICKET}] {name}/` — either way separate
from the dev skill's `docs/Stories/[{TICKET}] {name}/impl/`, which is not
namespaced this way, and the two design roots never mix in the same parent
folder.

`design-review` is retired as a standalone skill; its parameterized WAF assessment
now lives as `patterns/waf-review.md`, extended with a `solution` target (fixing a
pre-existing bug where Solution's design review gate called `/design-review
{TICKET} solution`, a target the old skill never actually defined).

## Substitutions

| Placeholder                       | Source                                        | Notes                                                                                                                                                                                                                                                                                                                                         |
| --------------------------------- | --------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `{{PROJECT_KEY}}`                 | Q5 — ticket prefix                            | Replaces the tracker project key in ticket references                                                                                                                                                                                                                                                                                         |
| `{{DESIGN_ARCHITECT_AGENT}}`      | Q — design lifecycle scope (see Conditionals) | The read-only architecture agent Research/Evaluate/Solution/Publish delegate to. Always the literal runtime token `{resolved architect agent}`, in every mode — never a fixed agent name substituted at generation time. Context Gathering Step 3 is the only place that ever names `@architect`/`@product-architect` literally.              |
| `{{DESIGN_DOCS_ROOT}}`            | Q — design lifecycle scope (see Conditionals) | Where settled decisions land. Always the literal runtime token `{dest docs}` (and `{source docs}` where a step reads rather than writes), in every mode — never a fixed path substituted at generation time                                                                                                                                   |
| `{{DESIGN_STORIES_ROOT}}`         | Q — design lifecycle scope (see Conditionals) | Where this design's story folder lives under `docs/Stories/`. Always the literal runtime token `{stories root}`, in every mode, for the same reason as `{{DESIGN_DOCS_ROOT}}` — kept separate because it names a different path (`docs/Stories/...`, not `docs/Target Architecture (HLD)/...` or `docs/{{PRODUCT_CONTEXT_DIR}}/...`)          |
| `{{DESIGN_CONTEXT_STEP}}`         | Q — design lifecycle scope (see Conditionals) | The full body of Context Gathering Step 3 — how the design's destination (and, now, the architect agent and Stories root) is identified and written to `design/Report.md`, then read sources recorded into `## Evidence`. Structurally different per mode, not just a value swap — this is the _only_ substitution that still varies per mode |
| `{{PRODUCT_CONTEXT_DIR}}`         | Q — design lifecycle scope (see Conditionals) | Folder name under `docs/` for the shared product-context layer, only asked when Product-context-scoped or Two-track. Default suggestion: `Product Context`                                                                                                                                                                                    |
| `{{DESIGN_LIFECYCLE_SCOPE_NOTE}}` | Q — design lifecycle scope (see Conditionals) | One callout line in the router stating what `{{provider:invoke:design}}` targets and where output lands                                                                                                                                                                                                                                       |
| `{{DESIGN_HANDOFF_NOTE}}`         | Developer describes the repo topology         | One line explaining where implementation tickets are actually built — e.g. "Most designs are implemented in the owning downstream repo, not here" for a multi-repo product, or omitted entirely for a single-repo project                                                                                                                     |
| `{{DOC_PRINCIPLES_ARTICLE}}`      | Q — Doc Principles article path               | Passed to `@docs-writer` in Publish Step 3; same value as `docs-writer/INTENT.md`'s substitution                                                                                                                                                                                                                                              |
| `{{WAF_PILLARS_TABLE}}`           | Q11 — WAF framework                           | Pillar definitions table (pillar name + key questions), used by both Evaluate's inline assessment and `patterns/waf-review.md`                                                                                                                                                                                                                |
| `{{WAF_PILLAR_SHORTNAMES}}`       | Q11 — WAF framework                           | Comma-separated abbreviated pillar names for `patterns/waf-review.md`'s `--pillars=` valid values                                                                                                                                                                                                                                             |
| `{{WAF_PILLAR_COLUMNS}}`          | Q11 — WAF framework                           | Pillar names as Evaluate's tradeoffs-table column headers                                                                                                                                                                                                                                                                                     |
| `{{WAF_PILLAR_ROWS}}`             | Q11 — WAF framework                           | Markdown table rows for `templates/evaluate.md`'s Tradeoffs table                                                                                                                                                                                                                                                                             |
| `{{WAF_PILLAR_SUMMARY_ROWS}}`     | Q11 — WAF framework                           | Markdown table rows for the Report.md WAF summary (pillar · rating · headline)                                                                                                                                                                                                                                                                |
| `{{WAF_FRAMEWORK}}`               | Q11 — WAF framework                           | Framework name used in Evaluate's closing-assessment heading, e.g. "Azure Well-Architected Framework"                                                                                                                                                                                                                                         |

Transition IDs are never substituted here — design only asks `@scrum-master` to
transition a ticket by state name ("In Progress", "Done", …); the tracker agent
resolves the ID from its own definition. Keeping that mapping in one place
(`@scrum-master`) avoids the two skills drifting out of sync — same rule as
`dev/INTENT.md`.

## Conditionals

- **Design lifecycle scope** — ask at bootstrap time (Q10 in the [launch questions](../../../references/launch/02-launch-questions.md)) which of three modes `{{provider:invoke:design}}` runs in. This is **one decision, used consistently** across every stage reference and pattern in this skill — not a per-stage choice. `{{provider:invoke:dev}}` is unaffected in every mode.

  **In every mode**, `{{DESIGN_DOCS_ROOT}}`, `{{DESIGN_STORIES_ROOT}}`, and
  `{{DESIGN_ARCHITECT_AGENT}}` resolve, everywhere they appear in every stage
  reference and pattern, to the **literal runtime tokens** `{dest docs}` /
  `{source docs}` / `{stories root}` / `{resolved architect agent}` — never to
  a fixed value substituted at generation time, in any mode, including the two
  single-track ones. What varies by mode is only `{{DESIGN_CONTEXT_STEP}}`:
  how Context Gathering's Step 3 identifies the track, writes those fields
  into `design/Report.md`'s `## Context` section, and reads the relevant
  source docs into `## Evidence`. Launch's job is to configure that
  identification step — whether it's a real per-session question (Two-track)
  or a fixed answer written without asking (single-track, since there's
  nothing to identify) — never to bake a literal agent name or path into the
  rest of the skill's text.

  - **Project-scoped** (default — most single-repo projects): `{{provider:invoke:design}}` always targets this project's own architecture.
    - `{{DESIGN_CONTEXT_STEP}}` = "This deployment has only the Project track — write `Track: Project`, `Source docs: docs/Target Architecture (HLD)/`, `Architect agent: @architect`, `Implementation note: Project designs cover this repo's own containers — {{provider:invoke:dev}} in this repo is the expected next step.` into `design/Report.md`'s `## Context` section with no question asked. Then read `docs/Target Architecture (HLD)/README.md` to find the active version, resolve the subfolder (list existing containers, ask the developer which one — or a new name if none fit), and write `Dest docs: docs/Target Architecture (HLD)/{subfolder}` and `Stories root: docs/Stories/design/`. Finally, read the relevant container doc(s) and NFR docs for the areas this ticket touches, recording each into `## Evidence`."
    - Do not deploy `patterns/context-resolution.md` or `product-architect`. `{{PRODUCT_CONTEXT_DIR}}` is not asked.

  - **Product-context-scoped** (a repo whose entire purpose is a shared cross-project docs layer with no target architecture of its own): `{{provider:invoke:design}}` always targets the shared product-context layer.
    - `{{DESIGN_CONTEXT_STEP}}` = "This deployment has only the Product track — write `Track: Product`, `Source docs: docs/{{PRODUCT_CONTEXT_DIR}}/`, `Architect agent: @product-architect`, `Implementation note: Most Product designs are implemented in the owning downstream platform repo(s) — offer {{provider:invoke:dev}} in this repo only if the implementation tickets genuinely target this repo's own code.` into `design/Report.md`'s `## Context` section with no question asked. Then resolve the subfolder (list the product-context subfolders, ask the developer which one — or a new name if none fit), and write `Dest docs: docs/{{PRODUCT_CONTEXT_DIR}}/{subfolder}` and `Stories root: docs/Stories/product-design/`. Finally, read relevant docs under each of those subfolders, recording each into `## Evidence`."
    - Deploy `canonical/agents/product-architect/TEMPLATE.md`. Do not deploy `patterns/context-resolution.md`.

  - **Two-track** (a repo that needs both: its own target architecture _and_ a shared cross-project product-context layer, chosen per design session):
    - `{{DESIGN_CONTEXT_STEP}}` = "Apply `{{provider:skills_root}}/design/patterns/context-resolution.md` — resolve which track this is (Product or Project), then which subfolder within it, and write the resolved Track, Source docs, Dest docs, Stories root, Subfolder, Architect agent, and Implementation note into the `## Context` section of `design/Report.md` (created in this same step, at the resolved Stories root). The pattern also reads the resolved Source docs path and records into Evidence — see its own final paragraph."
    - Deploy `patterns/context-resolution.md` — resolve its lookup table's Product row using `{{PRODUCT_CONTEXT_DIR}}`; its Project row is fixed. Its Stories root row is a fixed pair (`docs/Stories/product-design/` / `docs/Stories/design/`) regardless of mode — only Two-track needs the runtime branch, since the other two modes have exactly one value and never ask. Deploy `canonical/agents/product-architect/TEMPLATE.md` alongside `@architect` — both agents exist side by side.
    - `{{DESIGN_HANDOFF_NOTE}}` resolves to the runtime instruction: "Read the Implementation note from `design/Report.md`'s `## Context` section before publishing implementation tickets." — not a fixed string, since the note varies by which track the session resolved to.
    - `{{DESIGN_LIFECYCLE_SCOPE_NOTE}}` resolves to: `> 🗂 **Two-track design** — Product (`docs/{{PRODUCT_CONTEXT_DIR}}/`) or Project (`docs/Target Architecture (HLD)/`). Resolved once in Context Gathering Step 3 (`patterns/context-resolution.md`) and recorded in `design/Report.md`'s `## Context` section; every later phase reads it from there.`

- If Q5 is "none" (no issue tracker): remove every tracker reference across `TEMPLATE.md`, `references/01-context-gathering.md` (the tracker-fetch step), and `references/02-ceremony.md` (the tracker-transition step), plus Completion's Step 4 tracker-sync section; use free-text ticket titles instead.
- If Q11 is "None" (no WAF framework): omit `patterns/waf-review.md` entirely, remove Solution's Step 7, and remove Evaluate's Step 5 (closing WAF assessment) — keep only Integration Complexity and Vendor Lock-in columns in Evaluate's tradeoffs table.
- If Q11 is AWS WAF: 6 pillars (Security, Reliability, Cost Optimisation, Operational Excellence, Performance Efficiency, Sustainability). If Q11 is Azure WAF: 5 pillars (Reliability, Security, Cost Optimization, Operational Excellence, Performance Efficiency). Adjust `{{WAF_PILLAR_SHORTNAMES}}` to match.

## Verify checklist

- [ ] TEMPLATE.md starts with `---` frontmatter containing `name:` (skill name) and `description:` (trigger conditions for this skill)
- [ ] Route section covers all ten entry forms: `context-gathering`, `ceremony`, `frame`, `research`, `evaluate`, `solution`, `review-gate`, `address-feedback`, `publish`, `complete`, and bare-ticket full chain, plus the ambiguous-stage-word ask
- [ ] Resume Detection uses `*{TICKET}*/**` wildcard, never `[{TICKET}]*`
- [ ] No literal tracker-specific wording (e.g. "Jira") in `TEMPLATE.md` or any `references/*.md` — tracker activity is named generically and delegated to `@scrum-master`, never described with tracker-specific vocabulary or transition IDs
- [ ] `references/02-ceremony.md` (tracker transition + branch checkout) runs only after `references/01-context-gathering.md` has resolved the title/summary and created `design/Report.md` — the branch slug depends on it
- [ ] `patterns/waf-review.md`'s target table includes `solution` → `solution/Architecture.md` + `solution/Design*.md`, and `references/06-solution.md` Step 7 applies it directly rather than invoking a retired `/design-review` command
- [ ] `references/05-evaluate.md` Step 5 keeps its own inline WAF assessment — it does not call `patterns/waf-review.md` (deliberate: minimal consolidation, not full unification)
- [ ] Each phase section in TEMPLATE.md has an explicit phase-boundary stop with the exact quoted question format; any additional human gates are owned by the stage reference and do not replace the phase boundary
- [ ] TEMPLATE.md only delegates — no implementation logic, no step details (those live in `references/`)
- [ ] Completion's Step 4 asks for effort spent, then delegates the worklog + Done/rejected transition to `@scrum-master` by state name only — no `{{JIRA_TRANSITION_DONE}}` substitution anywhere
- [ ] `patterns/task-tracking.md` covers stage-level tracking only (ten stages) — no per-step section, since design has no analog to `dev`'s Implement steps
- [ ] Every Phase-row string across `TEMPLATE.md`, `references/*.md`, and `templates/report.md` lists all ten stages in order (`🎯 Context Gathering · 🚀 Ceremony · 📋 Frame · 🔍 Research · 🏗 Evaluate · 📦 Solution · 🔎 Review · 💬 Address Feedback · 📤 Publish · 🏁 Completion`) with consistent status icons
- [ ] Every story-folder path reference across the skill uses `{{DESIGN_STORIES_ROOT}}` (or `$DESIGN_DIR` once resolved) rather than a hardcoded `docs/Stories/design/...` or `docs/Stories/product-design/...` literal — the two exceptions are `patterns/context-resolution.md`'s lookup table and `INTENT.md`'s own Conditionals, which document the fixed per-mode values themselves. Never bare `docs/Stories/[{TICKET}] {name}`, which is the `dev` skill's namespace. `TEMPLATE.md`'s Resume Detection glob is the one place that must check both roots explicitly (Two-track), since the track isn't resolved yet at that point
- [ ] Every `patterns/*.md` and `templates/*.md` reference across `TEMPLATE.md` and `references/*.md` uses the subfolder path, never the old flat `pattern-X.md` / `X-template.md` form
- [ ] In every mode (not just Two-track): `{{DESIGN_DOCS_ROOT}}`, `{{DESIGN_STORIES_ROOT}}`, and `{{DESIGN_ARCHITECT_AGENT}}` resolve to the literal runtime tokens (`{dest docs}`, `{source docs}`, `{stories root}`, `{resolved architect agent}`) everywhere they appear outside Context Gathering's Step 3 — never to a fixed path/agent name baked into Research, Evaluate, Solution, Publish, Completion, or any pattern file
- [ ] Story folder globs use `*{TICKET}*/**` wildcard, never `[{TICKET}]*`, everywhere they appear

- [ ] Design metrics companions are installed verbatim; stage IDs, review waits, feedback skips/retries, and Completion's ticket-level finalization are wired through `patterns/metrics.md`
- [ ] Design metrics live in `design/stat.json` and update only `design/Report.md`'s generated block; implementation metrics remain separate in `impl/stat.json`

- [ ] The design metrics CLI and its own `scripts/constants.mjs` / `scripts/utils.mjs` work when installed alone; its standalone-install test passes

---
skill: agents/docs-writer
output: {{provider:agents_root}}/docs-writer.{{provider:agent_extension}}
---

## Purpose

When adding, renaming or removing pages, verify existing documentation-site navigation
still resolves. This responsibility is conditional on a site configuration being
present; it does not require creating one.

Permanent doc writer invoked any time architecture or project docs need to be created or updated — during the design lifecycle's Publish stage, the dev lifecycle's Document stage, or any inline conversation. Reads the project's Documentation Principles article before writing, enforces diagram-first format with colored Mermaid, and applies the certainty principle. Checks the terminology registry before naming a concept and appends new project-specific terms it coins. Also maintains existing docs-site navigation when pages are added, renamed or removed.

## Substitutions

| Placeholder                  | Source                          | Notes                                                         |
| ---------------------------- | ------------------------------- | ------------------------------------------------------------- |
| `{{DOC_PRINCIPLES_ARTICLE}}` | Q — Doc Principles article path | e.g. `docs/Engineering Guide/Documentation/01 Principles.md`  |
| `{{DOC_STRUCTURE_ARTICLE}}`  | Q — Doc Structure article path  | e.g. `docs/Engineering Guide/Documentation/02 Structure.md`   |
| `{{TERMINOLOGY_REGISTRY}}`   | Q — Terminology registry path   | e.g. `docs/Engineering Guide/Documentation/07 Terminology.md` |

## Conditionals

None.

## Verify checklist

- [ ] `{{DOC_PRINCIPLES_ARTICLE}}` resolves to a file that exists in the project
- [ ] `{{DOC_STRUCTURE_ARTICLE}}` resolves to a file that exists in the project
- [ ] `{{TERMINOLOGY_REGISTRY}}` resolves to a file that exists in the project
- [ ] Agent description mentions it can be invoked from any phase (not just the Publish stage)
- [ ] Agent points to Core doc principles in `{{DOC_PRINCIPLES_ARTICLE}}` rather than restating diagram/coloring/certainty/length rules
- [ ] Agent checks `{{TERMINOLOGY_REGISTRY}}` before naming a concept and appends new project-specific terms rather than silently coining a synonym
- [ ] Output format (one-line summary per doc) is described

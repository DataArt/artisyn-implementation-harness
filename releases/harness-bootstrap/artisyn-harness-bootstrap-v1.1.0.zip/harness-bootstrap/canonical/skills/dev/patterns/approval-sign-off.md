# Decision and approval boundaries

Apply throughout the dev lifecycle. A request to run the flow authorizes context
inspection, planning, reversible local edits within scope, relevant checks, report
updates, and routine stage transitions. Existing authorization persists; do not ask
again at each file, finding, step, or phase. Announce progress and continue.

**Explicit stop-and-wait gates always win.** Where a stage reference marks a point
with "Stop and wait", a HARD STOP banner, or a mandatory approval mechanism (e.g.
Plan Mode approval, per-step verification confirmation, branch checkout confirmation),
that gate is a human checkpoint by design — this pattern's routine-work authorization
never overrides it, skips it, or downgrades it to an announcement.

## Sign-off gates

A **sign-off** is a stop-and-wait gate where the developer must explicitly approve
content, or personally run a manual operation, before the lifecycle proceeds —
distinct from routine authorized work, which continues without asking. Every
sign-off blocks progress until an explicit reply; silence, a later unrelated
message, or an automated notification is never a sign-off. The fixed sign-off
points in this lifecycle:

- **Context Gathering Step 4** — developer signs off on the summarized scope/sources
  before `0-intent.md` is written.
- **Ceremony Step 2** — branch checkout is a manual operation: propose the exact
  `git checkout` command and wait for the developer to run it and confirm — never
  run it yourself.
- **Plan Step 3** — developer signs off on the _drafted_ plan via Plan Mode's
  approve cycle.
- **Plan Step 4 rework** — a direct edit to `1-plan.md` in response to an
  architecture-audit finding needs its own sign-off on the diff before re-audit and
  finalization; a re-audit `go` verdict checks HLD alignment, not developer approval,
  and never substitutes for it. (Rework done by re-entering Plan Mode is already
  covered by its own approve cycle.)
- **Plan Step 5** — a second, distinct sign-off on the _persisted_ `1-plan.md` as it
  actually landed on disk (via `patterns/write-confirm.md`), after any Step 4
  rework is folded in — before `1-plan.md` is immutable and Implement starts.
  Step 3's approval of the draft and any Step 4 per-finding diff sign-offs do not
  substitute for this whole-artifact look.
- **Plan Step 6** — committing `1-plan.md` is a manual operation like Ceremony's
  checkout: propose the exact commit command and wait for the developer to run it
  and confirm before advancing to Implement — never commit yourself.
- **Implement Step 3** — developer signs off on each step's verification (HARD STOP)
  and personally runs and confirms each commit before the next step starts — never
  commit yourself. A worker's satellite-review `go` verdict (`patterns/satellite-review.md`)
  is an input to this gate, not a substitute for it — the orchestrator still runs
  this gate in full, and the worker never presents to the developer directly.

Running an available, non-guarded check yourself (a build, typecheck, curl,
`terraform validate`) as a debugging aid is routine authorized work and does not
require asking first — but it never substitutes for the sign-off itself.
Verification is a developer confirmation gate, not something self-certified because
a command exited 0 in your sandbox: your sandbox is not the developer's machine, and
tool availability, versions, or network behavior can differ. Report exactly what you
ran and its real result, then still present every verification item from the plan
and stop and wait; a self-run check answers whether it passed for you, never whether
the developer signs off to proceed. Having Bash access, or a delegated worker lacking
a tool, is never a reason to take a sign-off gate over yourself.

Do not add, remove, or weaken a sign-off gate as a side effect of an unrelated change;
touching one requires calling it out explicitly, the same way this section does. This
never happens implicitly via `patterns/approval-intelligent.md`, which only governs
checkpoints explicitly designated there as using it — never a gate in the list above.

Ask only when a concrete decision or action needs human input:

- Material scope, acceptance criteria, architecture or security tradeoffs not already
  settled. Prepare the plan or proposed change first; combine related choices once.
- Accepting a real unresolved risk or deferring required work. Record the decision,
  rationale and attribution; never treat silence as acceptance.
- Verification requiring human judgment, credentials or access unavailable to the
  agent. Complete all available checks first and request the specific missing check —
  except at a sign-off gate above, where every item the developer needs to
  meaningfully confirm is presented regardless of how many you already ran yourself;
  that gate's completeness requirement is not weakened by this bullet. At Implement
  Step 3, that item set is adapted to what the step actually became (see its own
  instructions) rather than a fixed copy of the plan's original wording — adapting
  _what's_ asked to match reality is not the same as asking for _less_, and never
  drops an item because it was merely already run once.
- External mutations (tracker tasks, publishing, deployment, migrations), destructive
  operations, or commits when not already authorized. Present exact targets and
  prepared content/diffs before asking. Respect project guarded-command rules.

Outside the fixed sign-off gates above, a local fix is not itself a commit approval
gate: keep commits logical, update the report before committing, and reuse
authorization for subsequent in-scope commits; when commits are developer-run,
offer messages without blocking independent local work, waiting only when the next
action actually depends on that commit. Where a sign-off gate above names a specific
commit (Plan Step 6, Implement Step 3, Document's archival commit), that gate's
explicit stop-and-wait governs instead — this paragraph never shortens it.

Archive a local story only after closure checks pass. Its reversible move does not
need a separate permission prompt within an authorized full flow. Never overwrite an
existing destination. Local archival does not authorize a tracker Done transition.
A direct-stage request ends after that stage; it does not authorize the rest of the flow.
